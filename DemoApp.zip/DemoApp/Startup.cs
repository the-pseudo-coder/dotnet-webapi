// Startup.cs
using System.Text;
using FluentValidation;
using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using Microsoft.AspNetCore.Authorization;


namespace DemoApp
{
    public class Startup
    {
        public IConfiguration Configuration { get; }
        public IWebHostEnvironment Env { get; }

        public Startup(IConfiguration configuration, IWebHostEnvironment env)
        {
            Configuration = configuration;
            Env = env;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            // --- MVC + API behavior (automatic 400 for model validation)
            services.AddControllers()
                .ConfigureApiBehaviorOptions(options =>
                {
                    // Use default ProblemDetails response on invalid modelstate
                    options.InvalidModelStateResponseFactory = context =>
                    {
                        var pd = new ValidationProblemDetails(context.ModelState)
                        {
                            Status = StatusCodes.Status400BadRequest,
                            Title = "One or more validation errors occurred."
                        };
                        return new BadRequestObjectResult(pd) { ContentTypes = { "application/problem+json" } };
                    };
                });

            // --- Configure FormOptions (upload limits)
            services.Configure<FormOptions>(opts =>
            {
                opts.MultipartBodyLengthLimit = 1024 * 1024 * 200; // 200 MB
            });

            // --- DI registrations: transient, scoped, singleton
            services.AddTransient<ITransientService, TransientService>();
            services.AddScoped<IScopedService, ScopedService>();
            services.AddSingleton<ISingletonService, SingletonService>();

            // Singleton that needs scoped services should use IServiceScopeFactory inside; see SingletonService example

            // --- Multiple implementations
            services.AddScoped<INotifier, EmailNotifier>();
            services.AddScoped<INotifier, SmsNotifier>();
            // Resolve IEnumerable<INotifier> to get both

            // --- Open generic registration
            services.AddScoped(typeof(IRepository<>), typeof(Repository<>));

            // --- HttpContext accessor
            services.AddHttpContextAccessor();

            // --- FluentValidation
            services.AddFluentValidationAutoValidation();
            services.AddValidatorsFromAssemblyContaining<Startup>();

            // --- Authentication: Cookies + JWT
            // Cookie auth (for UI pages)
            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddCookie(CookieAuthenticationDefaults.AuthenticationScheme, opts =>
            {
                opts.LoginPath = "/account/login";
                opts.Cookie.HttpOnly = true;
                opts.Cookie.SecurePolicy = CookieSecurePolicy.Always;
            })
            .AddJwtBearer(JwtBearerDefaults.AuthenticationScheme, options =>
            {
                var key = Encoding.UTF8.GetBytes(Configuration["Jwt:Key"] ?? "very_secret_key_here_change");
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidIssuer = Configuration["Jwt:Issuer"] ?? "DemoIssuer",
                    ValidateAudience = true,
                    ValidAudience = Configuration["Jwt:Audience"] ?? "DemoAudience",
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ClockSkew = System.TimeSpan.FromMinutes(2)
                };

                // Example events: support token in query (SignalR) and check revocation
                options.Events = new JwtBearerEvents
                {
                    OnMessageReceived = ctx =>
                    {
                        // optionally allow token in query for specific paths
                        var accessToken = ctx.Request.Query["access_token"].FirstOrDefault();
                        var path = ctx.HttpContext.Request.Path;
                        if (!string.IsNullOrEmpty(accessToken) && path.StartsWithSegments("/hubs"))
                            ctx.Token = accessToken;
                        return Task.CompletedTask;
                    },
                    OnTokenValidated = ctx =>
                    {
                        // Here you can check for token revocation, jti etc.
                        return Task.CompletedTask;
                    }
                };
            });

            // --- Authorization: roles & policies
            services.AddAuthorization(options =>
            {
                options.AddPolicy("AdminOnly", p => p.RequireRole("Admin"));
                options.AddPolicy("OwnerOrAdmin", policy =>
                    policy.RequireAssertion(context =>
                        context.User.IsInRole("Admin") ||
                        context.User.HasClaim(c => c.Type == "resource_owner" && c.Value == "true")));
            });

            // Add health checks or others as needed
            services.AddHealthChecks();

            // Register any custom services that authorization handlers might need
            // services.AddSingleton<IAuthorizationHandler, SampleRequirementHandler>();

            // Example: register a service needed by singleton that will create scopes
            services.AddSingleton<ICronService, CronService>();

            // Add memory cache, logging, etc as needed
            services.AddMemoryCache();

            services.AddSwaggerGen();
            services.AddEndpointsApiExplorer(); // optional when using MapControllers + swagger

        }

        public void Configure(IApplicationBuilder app)
        {
            // --- Host-specific behavior
            if (Env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // Global exception handler for production
                app.UseExceptionHandler(errorApp =>
                {
                    errorApp.Run(async context =>
                    {
                        context.Response.ContentType = "application/problem+json";
                        var exFeature = context.Features.Get<IExceptionHandlerFeature>();
                        var ex = exFeature?.Error;

                        var problem = new ProblemDetails
                        {
                            Title = "An error occurred while processing your request.",
                            Status = StatusCodes.Status500InternalServerError,
                            Detail = Env.IsDevelopment() ? ex?.ToString() : null,
                            Instance = context.Request.Path
                        };

                        // Log here if you want (ILogger via DI can't be injected in this lambda easily without factory)
                        await context.Response.WriteAsJsonAsync(problem);
                    });
                });
            }

            // --- Custom early middleware: correlation id
            app.UseMiddleware<RequestCorrelationMiddleware>();

            // --- Static files (wwwroot)
            app.UseStaticFiles();

            // --- Routing
            app.UseRouting();

            // --- Swagger UI
            app.UseSwagger();
            app.UseSwaggerUI(c => { c.SwaggerEndpoint("/swagger/v1/swagger.json","v1"); });

            // --- Authentication & Authorization middleware order is important
            app.UseAuthentication();
            app.UseAuthorization();

            // --- Example of inline middleware (short)
            app.Use(async (context, next) =>
            {
                var logger = context.RequestServices.GetRequiredService<ILogger<Startup>>();
                logger.LogInformation("Inline Middleware - Request starting {Path}", context.Request.Path);
                await next();
                logger.LogInformation("Inline Middleware - Request finished {Status} for {Path}", context.Response.StatusCode, context.Request.Path);
            });

            // --- Add custom middleware as a pipeline component (class)
            app.UseMiddleware<RequestTimingMiddleware>(); // logs elapsed ms

            // --- Map controllers (attribute routing)
            app.UseEndpoints(endpoints =>
            {
                // Conventional route example
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");

                // Attribute routes will also work because we added controllers
                endpoints.MapControllers();

                // Health
                endpoints.MapHealthChecks("/health");
            });
        }
    }
}
