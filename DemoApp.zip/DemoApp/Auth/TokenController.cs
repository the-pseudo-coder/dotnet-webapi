// Auth/TokenController.cs - simple JWT issuance & refresh sketch
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;


namespace DemoApp.Auth
{
    [ApiController]
    [Route("auth")]
    public class TokenController : ControllerBase
    {
        private readonly IConfiguration _cfg;
        public TokenController(IConfiguration cfg) => _cfg = cfg;

        [HttpPost("token")]
        public IActionResult Token([FromBody] LoginRequest req)
        {
            // In production: validate username/password from DB, use hashed passwords
            if (req.Username != "alice" || req.Password != "password") return Unauthorized();

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, req.Username),
                new Claim(ClaimTypes.NameIdentifier, "42"),
                new Claim(ClaimTypes.Role, "Admin"),
                new Claim("resource_owner", "true") // custom claim used by policies
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_cfg["Jwt:Key"] ?? "very_secret_key_here_change"));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var expires = DateTime.UtcNow.AddMinutes(15);

            var token = new JwtSecurityToken(
                issuer: _cfg["Jwt:Issuer"] ?? "DemoIssuer",
                audience: _cfg["Jwt:Audience"] ?? "DemoAudience",
                claims: claims,
                expires: expires,
                signingCredentials: creds);

            var tokenStr = new JwtSecurityTokenHandler().WriteToken(token);

            // In real apps: issue refresh token (store hashed refresh token in DB)
            return Ok(new { access_token = tokenStr, expires_at = expires });
        }

        // DTO for login
        public record LoginRequest(string Username, string Password);
    }
}
