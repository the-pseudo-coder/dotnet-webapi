// Controllers/HomeController.cs - Conventional routing example (MVC style)
using Microsoft.AspNetCore.Mvc;

namespace DemoApp.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return Content("Hello from Home/Index - conventional routing");
        }

        public IActionResult About()
        {
            return Content("About page");
        }
    }
}
