// Controllers/ValuesController.cs
using System.Security.Claims;
using DemoApp.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DemoApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ValuesController : ControllerBase
    {
        private readonly ILogger<ValuesController> _logger;
        private readonly IEnumerable<INotifier> _notifiers;
        private readonly ISingletonService _singleton;

        public ValuesController(ILogger<ValuesController> logger, IEnumerable<INotifier> notifiers, ISingletonService singleton)
        {
            _logger = logger;
            _notifiers = notifiers;
            _singleton = singleton;
        }

        // Example: model binding from body + validation (DataAnnotations + FluentValidation)
        [HttpPost("users")]
        public IActionResult CreateUser([FromBody] CreateUserDto dto)
        {
            // On invalid model state, the InvalidModelStateResponseFactory in Startup will return ProblemDetails 400
            _logger.LogInformation("Creating user {Email}", dto.Email);
            return CreatedAtAction(nameof(GetUserById), new { id = 123 }, dto);
        }

        // Model binding from route and query and header
        [HttpGet("{id:int}")]
        public IActionResult GetUserById([FromRoute] int id, [FromQuery] bool includeDetails = false, [FromHeader(Name = "X-Correlation-ID")] string? correlation = null)
        {
            return Ok(new { Id = id, Include = includeDetails, Correlation = correlation });
        }

        // Bind from form (file upload)
        [HttpPost("upload")]
        [RequestSizeLimit(10_000_000)] // 10 MB
        public async Task<IActionResult> Upload([FromForm] FileUploadDto dto)
        {
            if (dto.File.Length == 0) return BadRequest("Empty file");
            // Validate signature, content type, etc (not shown)
            var filePath = Path.Combine(Path.GetTempPath(), Path.GetRandomFileName());
            await using var fs = System.IO.File.Create(filePath);
            await dto.File.CopyToAsync(fs);
            return Ok(new { filePath });
        }

        // Secured endpoint (JWT role-based)
        [HttpGet("secure/admin")]
        [Authorize(Roles = "Admin")]
        public IActionResult AdminOnly()
        {
            // Access claims
            var name = User.Identity?.Name ?? "unknown";
            return Ok($"Hello Admin {name}");
        }

        // Policy-based
        [HttpGet("secure/policy")]
        [Authorize(Policy = "AdminOnly")]
        public IActionResult ByPolicy() => Ok("Policy OK");

        // Use HttpContext directly
        [HttpGet("context/info")]
        public IActionResult ContextInfo()
        {
            var ctx = HttpContext;
            var trace = ctx.TraceIdentifier;
            var user = ctx.User?.Identity?.Name;
            return Ok(new { Trace = trace, User = user, SingletonId = _singleton.Id, ScopedFromSingleton = _singleton.GetScopedId() });
        }
    }
}
