// Validators.cs - FluentValidation
using FluentValidation;
using DemoApp.Models;

namespace DemoApp.Validators
{
    public class CreateUserDtoValidator : AbstractValidator<CreateUserDto>
    {
        public CreateUserDtoValidator()
        {
            RuleFor(x => x.Name).NotEmpty().MinimumLength(2);
            RuleFor(x => x.Email).EmailAddress().NotEmpty();
            RuleFor(x => x.Age).InclusiveBetween(1, 120);
        }
    }
}
