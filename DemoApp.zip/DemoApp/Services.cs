// Services.cs
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace DemoApp
{
    // Lifetimes
    public interface ITransientService { string Id { get; } }
    public class TransientService : ITransientService { public string Id { get; } = Guid.NewGuid().ToString(); }

    public interface IScopedService { string Id { get; } }
    public class ScopedService : IScopedService { public string Id { get; } = Guid.NewGuid().ToString(); }

    public interface ISingletonService { string Id { get; } string GetScopedId(); }
    // Bad: don't inject scoped into singleton. Good: use IServiceScopeFactory to create a scope when needed
    public class SingletonService : ISingletonService
    {
        private readonly IServiceScopeFactory _scopeFactory;
        public string Id { get; } = Guid.NewGuid().ToString();
        public SingletonService(IServiceScopeFactory scopeFactory) => _scopeFactory = scopeFactory;

        // create a scope on demand to resolve scoped service
        public string GetScopedId()
        {
            using var scope = _scopeFactory.CreateScope();
            var scoped = scope.ServiceProvider.GetRequiredService<IScopedService>();
            return scoped.Id;
        }
    }

    // Multiple implementations example
    public interface INotifier { Task NotifyAsync(string message); }
    public class EmailNotifier : INotifier
    {
        public Task NotifyAsync(string message) { Console.WriteLine($"Email: {message}"); return Task.CompletedTask; }
    }
    public class SmsNotifier : INotifier
    {
        public Task NotifyAsync(string message) { Console.WriteLine($"SMS: {message}"); return Task.CompletedTask; }
    }

    // Generic repository
    public interface IRepository<T> where T : class
    {
        IEnumerable<T> GetAll();
    }
    public class Repository<T> : IRepository<T> where T : class
    {
        public IEnumerable<T> GetAll() => Array.Empty<T>();
    }

    // Example of a singleton background-like service that needs scopes
    public interface ICronService { Task RunNowAsync(); }
    public class CronService : ICronService
    {
        private readonly IServiceScopeFactory _scopeFactory;
        private readonly ILogger<CronService> _logger;

        public CronService(IServiceScopeFactory scopeFactory, ILogger<CronService> logger)
        {
            _scopeFactory = scopeFactory; _logger = logger;
        }

        public async Task RunNowAsync()
        {
            using var scope = _scopeFactory.CreateScope();
            var scoped = scope.ServiceProvider.GetRequiredService<IScopedService>();
            _logger.LogInformation("Cron ran using scoped id {ScopedId}", scoped.Id);
            await Task.CompletedTask;
        }
    }
}
