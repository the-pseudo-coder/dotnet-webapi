// Models.cs
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;

namespace DemoApp.Models
{
    // Simple DTOs showing binding and validation
    public class CreateUserDto
    {
        [Required]
        public string Name { get; set; } = string.Empty;

        [Required, EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Range(1, 120)]
        public int Age { get; set; }
    }

    public class UpdateProfileDto
    {
        public string? DisplayName { get; set; }

        [Phone]
        public string? Phone { get; set; }
    }

    // Model with custom DataAnnotation
    public class FileUploadDto
    {
        [Required]
        public IFormFile File { get; set; } = default!;
    }
}
